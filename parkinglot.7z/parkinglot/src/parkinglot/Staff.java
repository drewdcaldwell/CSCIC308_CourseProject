package parkinglot;
public class Staff extends User {
    private static final long serialVersionUID = 1L;
    private static final int userType = 1;
    
    public Staff(int id, String fname, String mname, String lname) {
        super(id, fname, mname, lname);
    }
    
    public int getUType() { 
        return userType; 
    }
}
