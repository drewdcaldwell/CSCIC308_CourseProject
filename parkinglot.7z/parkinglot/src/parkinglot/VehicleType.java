package parkinglot;
public enum VehicleType {
    CAR,
    MOTORCYCLE,
    TRUCK
}