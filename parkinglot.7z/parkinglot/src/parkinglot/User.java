package parkinglot;

import java.io.Serializable;

public abstract class User implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int id2;
    private String fname2;
    private String mname2;
    private String lname2;
  
     public User(int id2, String fname2, String mname2, String lname2) {
		// TODO Auto-generated constructor stub
    	this.id2 = id2;
        this.fname2 = fname2;
        this.mname2 = mname2;
        this.lname2 = lname2;
	}

	public int getId() { return id2; }
    public String getFName() { return fname2; }
    public String getMName() { return mname2; }
    public String getLName() { return lname2; }
    
    abstract public int getUType();
}

