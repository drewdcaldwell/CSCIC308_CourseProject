package parkinglot;



	import java.io.Serializable;

	public class ParkingSpot implements Serializable {
	    private static final long serialVersionUID = 1L;
	    
	    private int spotNumber;
	    private boolean occupied;
	    private Vehicle vehicle;
	    
	    public ParkingSpot(int spotNumber) {
	        this.spotNumber = spotNumber;
	        this.occupied = false;
	        this.vehicle = null;
	    }
	    
	    // Getters and setters
	    public int getSpotNumber() { return spotNumber; }
	    public boolean isOccupied() { return occupied; }
	    public Vehicle getVehicle() { return vehicle; }
	    
	    public void parkVehicle(Vehicle vehicle) {
	        this.vehicle = vehicle;
	        this.occupied = true;
	    }
	    
	    public void removeVehicle() {
	        this.vehicle = null;
	        this.occupied = false;
	    }
	}

