package parkinglot;
public class Admin extends User {
    private static final long serialVersionUID = 1L;
    private static final int userType = 2;
    
    public Admin(int id, String fname, String mname, String lname) {
        super(id, fname, mname, lname);
    }
    
    public int getUType() { 
        return userType; 
    }
}
