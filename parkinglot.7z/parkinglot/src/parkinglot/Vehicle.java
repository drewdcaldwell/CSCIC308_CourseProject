package parkinglot;


import java.io.Serializable;

public class Vehicle implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String licensePlate;
    private String model;
    private VehicleType type;
    
    public Vehicle(String licensePlate, String model, VehicleType type) {
        this.licensePlate = licensePlate;
        this.model = model;
        this.type = type;
    }
    
    // Getters
    public String getLicensePlate() { return licensePlate; }
    public String getModel() { return model; }
    public VehicleType getType() { return type; }
}


