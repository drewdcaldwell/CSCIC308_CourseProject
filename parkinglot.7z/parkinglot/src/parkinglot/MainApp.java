package parkinglot;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

public class MainApp {
    private ArrayList<ParkingLot> parkingLots;       // List of parking lots
    private Map<Integer, Customer> customerAccounts; // Map of customer accounts
    private Map<Integer, Staff> staffAccounts;
    private Map<Integer, Admin> adminAccounts;
    private Map<Integer, SuperAdmin> superUserAccounts;
    private Scanner scanner;
   
    public MainApp() {
        parkingLots = new ArrayList<>();
        customerAccounts = new HashMap<>();
        staffAccounts = new HashMap<>();
        adminAccounts = new HashMap<>();
        superUserAccounts = new HashMap<>();
        scanner = new Scanner(System.in);
        loadAllUserData1();
   }
    public void saveData(String parkingLotFileName, String customerFileName) {
        // Save parking lots in readable format
        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(parkingLotFileName), StandardCharsets.UTF_8))) {
                
            for (ParkingLot lot : parkingLots) {
                writer.println("=== Parking Lot ===");
                writer.println("ID: " + lot.getId());
                writer.println("Name: " + lot.getName());
                writer.println("Capacity: " + lot.getCapacity());
                writer.println("Spots:");
                
                for (ParkingSpot spot : lot.getSpots()) {
                    writer.println("\tSpot " + spot.getSpotNumber() + 
                                 " [" + (spot.isOccupied() ? "Occupied" : "Available") + "]");
                    if (spot.getVehicle() != null) {
                        Vehicle v = spot.getVehicle();
                        writer.println("\t\tVehicle: " + v.getLicensePlate() + 
                                     " - " + v.getModel());
                    }
                }
                writer.println();
            }
        } catch (IOException e) {
            System.out.println("Error saving parking lots: " + e.getMessage());
        }

        // Save customer data in readable format
        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(customerFileName), StandardCharsets.UTF_8))) {
                
            for (Customer customer : customerAccounts.values()) {
                writer.println("=== Customer ===");
                writer.println("UserType: " + customer.getUType());
                writer.println("ID: " + customer.getId());
                writer.println("First Name: " + customer.getFName());
                writer.println("Middle Name: " + customer.getMName());
                writer.println("Last Name: " + customer.getLName());
                writer.println("Vehicles:");
                
                for (Vehicle vehicle : customer.getVehicles()) {
                    writer.println("\tLicense: " + vehicle.getLicensePlate());
                    writer.println("\tModel: " + vehicle.getModel());
                    writer.println("\tType: " + vehicle.getType());
                    writer.println();
                }
                writer.println();
            }
        } catch (IOException e) {
            System.out.println("Error saving customers: " + e.getMessage());
        }
    }
// Load parking lots and customer accounts from separate files
    @SuppressWarnings("unchecked")
	public void loadData(String parkingLotFileName, String customerFileName) {
        try (ObjectInputStream parkingLotIn = new ObjectInputStream(new FileInputStream(parkingLotFileName));
             ObjectInputStream customerIn = new ObjectInputStream(new FileInputStream(customerFileName))) {
            
            parkingLots = (ArrayList<ParkingLot>) parkingLotIn.readObject();
            customerAccounts = (Map<Integer, Customer>) customerIn.readObject();
            System.out.println("Data loaded successfully.");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading data: " + e.getMessage());
            parkingLots = new ArrayList<>(); // Reset to empty if loading fails
            customerAccounts = new HashMap<>();
        }
    }
    
    public void loadAllUserData1() {
        // Load all user data from respective files
        loadStaffData("staff.dat");
        loadAdminData("admin.dat");
        loadSuperUserData1("superuser.dat");
        
        // Display loading status
        System.out.println("\nUser Data Loading Status:");
        System.out.println("Staff Members: " + staffAccounts.size());
        System.out.println("Administrators: " + adminAccounts.size());
        System.out.println("Super Users: " + superUserAccounts.size());
    }

    @SuppressWarnings("unchecked")
	private void loadStaffData(String filename) {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            staffAccounts = (Map<Integer, Staff>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            staffAccounts = new HashMap<>();
        }
    }
    @SuppressWarnings("unchecked")
	private void loadAdminData(String filename) {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            adminAccounts = (Map<Integer, Admin>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            adminAccounts = new HashMap<>();
        }
    }
    @SuppressWarnings("unchecked")
	private void loadSuperUserData1(String filename) {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            superUserAccounts = (Map<Integer, SuperAdmin>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            superUserAccounts = new HashMap<>();
        }
    }
    public void saveAllData() {
        saveData("parkinglots.dat", "customers.dat");
        saveUserData("staff.dat", staffAccounts);
        saveUserData("admin.dat", adminAccounts);
        saveUserData("superuser.dat", superUserAccounts);
    }

    private void saveUserData(String filename, Map<Integer, ? extends User> accounts) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            out.writeObject(accounts);
        } catch (IOException e) {
            System.out.println("Error saving to " + filename + ": " + e.getMessage());
        }
    }


        public void run() {
            // Create a sample parking lot
            ParkingLot lot1 = new ParkingLot(1, "Carroll Stadium Parking Application", 100);
            parkingLots.add(lot1);

            String choice;
            do {
            	System.out.println("\nEnter 'y' to add customer and vehicle");
                System.out.println("Enter 'u' to add staff/admin/super user");
                System.out.println("Enter 'n' to exit");
                System.out.print("Your choice: ");
                choice = scanner.nextLine();

                if (choice.equalsIgnoreCase("y")) {
                    // Add new customer
                    addNewCustomer();
                    System.out.println("Enter Customer ID to add vehicle and park: ");
                    int customerId = scanner.nextInt();
                    scanner.nextLine(); // Clear buffer
                    addVehicleToCustomer(customerId, lot1);
                    System.out.println("Vehicle added to Customer and park succesfully ");
                }else if (choice.equalsIgnoreCase("u")) {
                	addUser();
                }
            } while (!choice.equalsIgnoreCase("n"));
   
            // Save the state
            saveData("parkinglots.dat", "customers.dat");

            // Display status
            displayParkingStatus(lot1);
        }
        //Code to save User such as Staff, Admin and SuperAdmin data to files.
        public void addUser() {
            System.out.println("\nSelect User Type:");
            System.out.println("1. Staff");
            System.out.println("2. Admin");
            System.out.println("3. Super User");
            System.out.print("Enter choice (1-3): ");
            
            int userType = scanner.nextInt();
            scanner.nextLine(); // Clear buffer
            
            System.out.print("Enter ID: ");
            int id = scanner.nextInt();
            scanner.nextLine();
            
            System.out.print("First Name: ");
            String fname = scanner.nextLine();
            System.out.print("Middle Name: ");
            String mname = scanner.nextLine();
            System.out.print("Last Name: ");
            String lname = scanner.nextLine();
            
            User newUser;
            switch(userType) {
                case 1:
                    newUser = new Staff(id, fname, mname, lname);
                    staffAccounts.put(id, (Staff)newUser);
                    saveToFile("staff.dat", staffAccounts);
                    break;
                case 2:
                    newUser = new Admin(id, fname, mname, lname);
                    adminAccounts.put(id, (Admin)newUser);
                    saveToFile("admin.dat", adminAccounts);
                    break;
                case 3:
                    newUser = new SuperAdmin(id, fname, mname, lname);
                    superUserAccounts.put(id, (SuperAdmin)newUser);
                    saveToFile("superadmin.dat", superUserAccounts);
                    break;
            }
            System.out.println("User added successfully!");
        }

       private void saveToFile(String filename, Map<Integer, ? extends User> accounts) {
            try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(
                    new FileOutputStream(filename), StandardCharsets.UTF_8))) {
                
                writer.println("=== User Records ===");
                for (User user : accounts.values()) {
                    writer.println("User Type: " + user.getClass().getSimpleName());
                    writer.println("ID: " + user.getId());
                    writer.println("Name: " + user.getFName() + " " + user.getMName() + " " + user.getLName());
                    writer.println("---------------");
                }
                System.out.println("Data successfully saved to " + filename);
                
            } catch (IOException e) {
                System.out.println("Error writing to file: " + e.getMessage());
            }
        }
       public void displayParkingStatus(ParkingLot lot) {
    	    System.out.println("\n=== Parking Lot Status ===");
    	    System.out.println("Location: " + lot.getName());
    	    System.out.println("Total Capacity: " + lot.getCapacity());
    	    
    	    int occupiedSpots = 0;
    	    System.out.println("\nOccupied Spots:");
    	    for (ParkingSpot spot : lot.getSpots()) {
    	        if (spot.isOccupied()) {
    	            occupiedSpots++;
    	            Vehicle vehicle = spot.getVehicle();
    	            System.out.printf("Spot %d: License: %s | Model: %s\n", 
    	                spot.getSpotNumber(), 
    	                vehicle.getLicensePlate(),
    	                vehicle.getModel());
    	        }
    	    }
    	    
    	    System.out.println("\nSummary:");
    	    System.out.println("Occupied Spots: " + occupiedSpots);
    	    System.out.println("Available Spots: " + (lot.getCapacity() - occupiedSpots));
    	    System.out.println("========================");
    	}
        
        public static void main(String[] args) {
            MainApp app = new MainApp();
            app.run();
        }

        // Additional functionality
        public void addNewCustomer() {
        	System.out.println("Enter Customer Profile Details:");
            System.out.print("Customer ID: ");
            int id=scanner.nextInt();
            System.out.print("First Name: ");
            scanner.nextLine();
            String fname = scanner.nextLine();
            System.out.print("Middle Name: ");
            String mname = scanner.nextLine();
            System.out.print("Last Name: ");
            String lname = scanner.nextLine();
            
            int newId = customerAccounts.size() + 1;
            Customer newCustomer = new Customer(newId, fname, mname, lname);
            customerAccounts.put(newId, newCustomer);
            
            System.out.println("Customer added successfully with ID: " + newId);
        }
        public void addVehicleToCustomer(int customerId, ParkingLot lot) {
            Customer customer = customerAccounts.get(customerId);
            if (customer != null) {
                System.out.println("\nEnter Vehicle Details:");
                System.out.print("License Plate: ");
                String plate = scanner.nextLine();
                System.out.print("Model: ");
                String model = scanner.nextLine();
                System.out.print("Vehicle Type (CAR/MOTORCYCLE/TRUCK): ");
                VehicleType type = VehicleType.valueOf(scanner.nextLine().toUpperCase());
                
                Vehicle vehicle = new Vehicle(plate, model, type);
                customer.addVehicle(vehicle);
                
                // Find first available parking spot
                for (ParkingSpot spot : lot.getSpots()) {
                    if (!spot.isOccupied()) {
                        spot.parkVehicle(vehicle);
                        System.out.println("Vehicle added and parked successfully!");
                        System.out.println("Customer: " + customer.getFName());
                        System.out.println("Parking Spot: " + spot.getSpotNumber());
                        return;
                    }
                }
                System.out.println("No available parking spots!");
            } else {
                System.out.println("Customer ID " + customerId + " not found.");
            }
        }
        

        public void findAvailableSpot(ParkingLot lot) {
            for (ParkingSpot spot : lot.getSpots()) {
                if (!spot.isOccupied()) {
                    System.out.println("First available spot: " + spot.getSpotNumber());
                    return;
                }
            }
            System.out.println("No available spots in this lot");
        }
        
}

   