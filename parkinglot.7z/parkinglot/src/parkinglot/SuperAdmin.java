package parkinglot;
public class SuperAdmin extends User {
    private static final long serialVersionUID = 1L;
    private static final int userType = 3;
    
    public SuperAdmin(int id, String fname, String mname, String lname) {
        super(id, fname, mname, lname);
    }
    
    public int getUType() { 
        return userType; 
    }
}