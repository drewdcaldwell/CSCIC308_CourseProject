package parkinglot;
     import java.io.Serializable;
	import java.util.ArrayList;
	import java.util.List;

	public class ParkingLot implements Serializable {
	    private static final long serialVersionUID = 1L;
	    
	    private int id;
	    private String name;
	    private int capacity;
	    private List<ParkingSpot> spots;
	    
	    public ParkingLot(int id, String name, int capacity) {
	        this.id = id;
	        this.name = name;
	        this.capacity = capacity;
	        this.spots = new ArrayList<>(capacity);
	        initializeSpots();
	    }
	    
	    private void initializeSpots() {
	        for (int i = 0; i < capacity; i++) {
	            spots.add(new ParkingSpot(i + 1));
	        }
	    }
	    
	    // Getters and setters
	    public int getId() { return id; }
	    public String getName() { return name; }
	    public int getCapacity() { return capacity; }
	    public List<ParkingSpot> getSpots() { return spots; }
	}



