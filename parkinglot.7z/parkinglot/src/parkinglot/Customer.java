package parkinglot;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Customer implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @SuppressWarnings("unused")
	private static final int userType=0;
    private int id;
    private String fname;
    private String mname;
    private String lname;
    private List<Vehicle> vehicles;
    
    public Customer(int id, String fname, String mname, String lname) {
    	this.id = id;
        this.fname = fname;
        this.mname = mname;
        this.lname = lname;
        this.vehicles = new ArrayList<>();
    }
    
    // Getters and setters
    public int getUType() { return userType; }
    public int getId() { return id; }
    public String getFName() { return fname; }
    public String getMName() { return mname; }
    public String getLName() { return lname; }
    public List<Vehicle> getVehicles() { return vehicles; }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }
}
