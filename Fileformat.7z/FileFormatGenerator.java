import java.io.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileFormatGenerator {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        createCustomerProfile();
        createStaffRecord();
        createAdminRecord();
        createSuperAdminRecord();
        createParkingLotInfo();
        
    }

    private static void createCustomerProfile() {
        try (PrintWriter writer = new PrintWriter("Cusprofile.cust")) {
            System.out.println("Enter Customer Profile Details:");
            System.out.print("User Type: ");
            int userType=scanner.nextInt();
            System.out.print("Customer ID: ");
            int cusid=scanner.nextInt();
            System.out.print("First Name: ");
            scanner.nextLine();
            String firstname = scanner.nextLine();
            System.out.print("Middle Name: ");
            String middlename = scanner.nextLine();
            System.out.print("Last Name: ");
            String lastname = scanner.nextLine();
            System.out.print("Plate Number: ");
            String platenumber = scanner.nextLine();
            
            writer.println("CUSTOMER PROFILE");
            writer.println("User Type: " + userType);
            writer.println("Customer ID: " + cusid);
            writer.println("First Name: " + firstname);
            writer.println("Middle Name: " + middlename);
            writer.println("Last Name: " + lastname);
            writer.println("Plate Number: " + platenumber);
            System.out.println("File created with filename Cusprofile.cust ");
        } catch (IOException e) {
            System.out.println("Error creating user profile: " + e.getMessage());
        }
    }

    private static void createStaffRecord() {
        try (PrintWriter writer = new PrintWriter("Staffrecord.staff")) {
            System.out.println("\nEnter Staff Details:");
            System.out.print("Staff ID: ");
            String id = scanner.nextLine();
            
            writer.println("EMPLOYEE RECORD");
            writer.println("Staff ID: " + id);
            System.out.println("File created with filename Staffrecord.staff ");
            } catch (IOException e) {
            System.out.println("Error creating employee record: " + e.getMessage());
        }
    }

    private static void createAdminRecord() {
        try (PrintWriter writer = new PrintWriter("AdminRecord.admin")) {
            System.out.println("\nEnter Admin Details:");
            System.out.print("Admin ID: ");
            String id = scanner.nextLine();
            
            writer.println("ADMIN DATA");
            writer.println("Admin ID: " + id);
            System.out.println("File created with filename AdminRecord.admin ");
            } catch (IOException e) {
            System.out.println("Error creating customer data: " + e.getMessage());
        }
    }
    private static void createSuperAdminRecord() {
        try (PrintWriter writer = new PrintWriter("SuperAdminRecord.super")) {
            System.out.println("\nEnter Super Admin Details:");
            System.out.print("SuperAdmin ID: ");
            int id = scanner.nextInt();
            System.out.print("Admin ID: ");
            int id1 = scanner.nextInt();
            System.out.print("Staff ID: ");
            int id2 = scanner.nextInt();
            
            writer.println("ADMIN DATA");
            writer.println("SuperAdmin ID: " + id);
            writer.println("Admin ID: " + id1);
            writer.println("Staff ID: " + id2);
            System.out.println("File created with filename SuperAdminRecord.super ");
            
            } catch (IOException e) {
            System.out.println("Error creating customer data: " + e.getMessage());
        }
    }

    private static void createParkingLotInfo() {
        try (PrintWriter writer = new PrintWriter("parkinglot.plt")) {
            System.out.println("\nEnter Parking Lot Details:");
            System.out.print("Lot Number: ");
            int lotNum = scanner.nextInt();
            System.out.print("Reservation ID: ");
            scanner.nextLine();
            String reserveid = scanner.nextLine();
            System.out.println("Customer ID: ");
            int cusid=scanner.nextInt();

            writer.println("PARKING LOT INFORMATION");
            writer.println("Lot Number: " + lotNum);
            writer.println("Reservation ID: " + reserveid);
            writer.println("Customer ID: " + cusid);
            System.out.println("File created with filename parkinglot.plt ");
        } catch (IOException e) {
            System.out.println("Error creating parking lot info: " + e.getMessage());
        }
    }

}

