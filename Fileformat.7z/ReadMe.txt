# The file format with filename are as follows:

1) Cusprofile.cust for customer profile
2) Staffrecord.staff for staff information
3) AdminRecord.admin for admin information
4) SuperAdminRecord.super for super admin information
5) parkinglot.plt for parking lot information

# The files can be opened in notepad.

# There are functions that create each file formats. These functions can be called in main program 
  to work as operator function with functionality of creating files.

#Currently each of the files are dynamic that means these files are overwritten by new data.

# Exception handling is used to catch any throw exceptions when  there is error.

# java file with source code is in the zip file. FileFormatGenerator.java

# bytecode  class file is also attached with zip file. FileFormatGenerator.class